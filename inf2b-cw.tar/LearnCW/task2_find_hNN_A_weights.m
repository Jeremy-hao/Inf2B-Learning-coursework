%
% Versin 0.9  (HS 06/03/2020)
%
% template script task2_find_hNN_A_weights.m
%
1;

% This task is meant for you to work using pen and paper (and calculator)
% so I write it on the report





